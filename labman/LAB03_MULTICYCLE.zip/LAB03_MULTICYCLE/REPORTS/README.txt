Timing reports (.rpt) are written here when the scripts run.
