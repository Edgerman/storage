# LAB03_MULTICYCLE - 01_normal_setup_fail
# Independent SDC file (no shared constraint script).
# Time unit: ns (from teaching_sta.lib)

create_clock -name CLK -period 4.0 [get_ports clk]
