# LAB05_FALSE_PATH - 01_before_false_path
# Independent SDC file (no shared constraint script).
# Time unit: ns (from teaching_sta.lib)

create_clock -name CLK -period 5.0 [get_ports clk]
