# LAB01_SETUP_HOLD - 02_setup_fixed
# Independent SDC file (no shared constraint script).
# Time unit: ns (from teaching_sta.lib)

create_clock -name CLK -period 5.0 [get_ports clk]
