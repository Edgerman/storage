# LAB01_SETUP_HOLD - 01_setup_fail
# Independent SDC file (no shared constraint script).
# Time unit: ns (from teaching_sta.lib)

create_clock -name CLK -period 4.0 [get_ports clk]
