
module.exports = async function(client) {
async function wPPAUopLvp() {
let builderVar_message;
client.on('ready', async (client) => {
  builderVar_message = await ((client.guilds.cache.get('866540307847708691')).channels.cache.find((category) => category.name === 'general')).send({
        content: String('hi'),
        embeds: [],
        components: [],
        files: []
      });

});

}


wPPAUopLvp();

}
  