
  module.exports = function(client) {
    require("./events.js")(client)
    return []
  }
  