
module.exports = function(client) {
let customCommands63293 = [];

async function LoktXsCYjX() {
let builderVar_message;
  /*
  Basic hello world example
  */


  /*
  You can register multiple
commands here
  */


  /*
  Emitted whenever a command is
received
  */

customCommands63293 = [...customCommands63293,
  {
    "name": ('hello').replaceAll(" ", "-").toLowerCase(),
    "type": 1,
    "description": 'Hello! 👋',
    "options": [

    ]
  },]
client.on("interactionCreate", async (interaction) => {
    if (!interaction.isChatInputCommand()) return;
    if (interaction.commandName == ("hello").replaceAll(" ", "-").toLowerCase()) {
        builderVar_message = await interaction.reply({
    content: 'Hello world!',
    embeds: [],
    ephemeral: false,
    components: [],
    files: [],
    fetchReply: true
  });

    }
});
}


LoktXsCYjX();


return customCommands63293
}
  