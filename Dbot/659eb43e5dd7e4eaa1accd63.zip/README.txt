

  Thank you for using the Domnio Bot Builder!

  ⚠️ Before starting check your NodeJS installation



  > INSTRUCTIONS


  -----------------------------------
  | 🪟 Windows                      |
  -----------------------------------
  
  > Download NodeJS from the url https://nodejs.org/en (do this only once)


  > Find the file 'run_windows.bat'
  > Double click on it



  -----------------------------------
  | 🐧 Linux                        |
  -----------------------------------

  The easiest way to run your bot on linux is:
  
  > Right-click the file 'run_linux.sh' to then click on "Properties"
  > Find an option called "Executable as a program" (or something like that) and enable it.
  > Close the "Properties" window
  > Right click again on the file
  > You will now see an option like "Run as Program". Select that and your bot will be live!

            --------------------- OR (VIA TERMINAL) -----------------------


  > Open the terminal at the current folder and run the command 'chmod u+x run_linux.sh' only once to make it executable

  > To start the bot run the command './run_linux.sh'


  