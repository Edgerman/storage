#!/bin/bash
npm i
node index.js